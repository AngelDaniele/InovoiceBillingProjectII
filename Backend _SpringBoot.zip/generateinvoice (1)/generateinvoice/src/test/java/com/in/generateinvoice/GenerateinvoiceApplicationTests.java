package com.in.generateinvoice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GenerateinvoiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
