package com.in.generateinvoice.repository;

import com.in.generateinvoice.model.ProjectEmployees;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProjectEmployeeRepository extends JpaRepository<ProjectEmployees,Integer> {



    List<ProjectEmployees> findByProject_ProjectId(String projectId);

//    ProjectEmployees  findById(int projectEmployeeId);
}




