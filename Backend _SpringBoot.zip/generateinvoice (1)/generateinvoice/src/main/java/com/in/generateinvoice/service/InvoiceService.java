package com.in.generateinvoice.service;

import com.in.generateinvoice.model.*;
import com.in.generateinvoice.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class InvoiceService {


    @Autowired
    BillGenerateRepository billGenerateRepository;


    @Autowired
    private InvoiceRepository invoiceRepository;

    @Autowired
    private DesignationSummaryRepository designationSummaryRepository;

    @Autowired
    private BGTableRepository bgTableRepository;

    @Autowired
    ProjectEmployeeRepository projectEmployeesRepository;

    @Autowired
    private ProjectRepository projectRepository;

    public Invoice createInvoice(int billGenerateTableId) {

        BillGenerate billGenerate = billGenerateRepository.findById(billGenerateTableId)
                .orElseThrow(() -> new IllegalArgumentException("BillGenerate not found"));


        ProjectEmployees projectEmployees = billGenerate.getProjectEmployees();
        Project project = billGenerate.getProject();


        int budget = project.getBudget();

        List<BGTable> bgTableEntries = bgTableRepository.findAllByBillGenerate_BillGenerateTableId(billGenerateTableId);
        BigDecimal subtotal = BigDecimal.ZERO;

        for (BGTable bgTable : bgTableEntries) {
            subtotal = subtotal.add(new BigDecimal(bgTable.getTotalAmount()));
        }


        BigDecimal cgstPercentage = new BigDecimal("9.00"); // 9% CGST
        BigDecimal sgstPercentage = new BigDecimal("9.00"); // 9% SGST

        BigDecimal cgst = subtotal.multiply(cgstPercentage.divide(new BigDecimal("100")));
        BigDecimal sgst = subtotal.multiply(sgstPercentage.divide(new BigDecimal("100")));


        BigDecimal totalAmount = subtotal.add(cgst).add(sgst);


        if (totalAmount.compareTo(new BigDecimal(budget)) > 0) {
            throw new IllegalArgumentException("TotalAmount exceeds the project budget");
        }

        // Create and save the Invoice
        Invoice invoice = new Invoice();
        invoice.setBillGenerateTableId(billGenerateTableId);
        invoice.setCgst(cgst);
        invoice.setSgst(sgst);
        invoice.setSubtotal(subtotal);
        invoice.setTotalAmount(totalAmount);

        return invoiceRepository.save(invoice);
    }




//    public Invoice createInvoice(int billGenerateTableId) {
//        // Retrieve the totalAmount from BGTable
//        List<BGTable> bgTableEntries = bgTableRepository.findAllByBillGenerate_BillGenerateTableId(billGenerateTableId);
//
//        BigDecimal subtotal = BigDecimal.ZERO;
//
//        // Calculate subtotal
//        for (BGTable bgTable : bgTableEntries) {
//            subtotal = subtotal.add(new BigDecimal(bgTable.getTotalAmount()));
//        }
//
//        // Calculate cgst and sgst based on 9% of subtotal
//        BigDecimal cgstPercentage = new BigDecimal("9.00"); // 9% CGST
//        BigDecimal sgstPercentage = new BigDecimal("9.00"); // 9% SGST
//
//        BigDecimal cgst = subtotal.multiply(cgstPercentage.divide(new BigDecimal("100")));
//        BigDecimal sgst = subtotal.multiply(sgstPercentage.divide(new BigDecimal("100")));
//
//        // Calculate totalAmount
//        BigDecimal totalAmount = subtotal.add(cgst).add(sgst);
//
//        // Create and save the Invoice
//        Invoice invoice = new Invoice();
//        invoice.setBillGenerateTableId(billGenerateTableId);
//        invoice.setCgst(cgst);
//        invoice.setSgst(sgst);
//        invoice.setSubtotal(subtotal);
//        invoice.setTotalAmount(totalAmount);
//
//        return invoiceRepository.save(invoice);
//    }




    public Invoice getInvoiceByBillGenerateTableId(int billGenerateTableId) {

        return invoiceRepository.findByBillGenerateTableId(billGenerateTableId);
    }

}









