package com.in.generateinvoice.service;

import com.in.generateinvoice.model.Project;
import com.in.generateinvoice.model.SubProject;
import com.in.generateinvoice.model.SubProjectUI;
import com.in.generateinvoice.repository.ProjectRepository;
import com.in.generateinvoice.repository.SubProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class SubProjectService {

    @Autowired
    private SubProjectRepository subProjectRepository;

    @Autowired
    private ProjectRepository projectRepository;



    public SubProject saveSubProjectUIWithAutoUpdate(SubProjectUI subProjectUI) {

        String projectId = subProjectUI.getProjectId();


        Project project = projectRepository.findByProjectId(projectId);

        if (project != null) {

            SubProject subProject = new SubProject();
            subProject.setSubProjectId(subProjectUI.getSubProjectId());
            subProject.setStartDate(subProjectUI.getStartDate());
            subProject.setEndDate(subProjectUI.getEndDate());
            subProject.setBudget(subProjectUI.getBudget());
            subProject.setProject(project);


            SubProject savedSubProject = subProjectRepository.save(subProject);


            updateProjectDetails(project);

            return savedSubProject;
        } else {
            throw new IllegalArgumentException("Project not found");
        }
    }


    private void updateProjectDetails(Project project) {
        List<SubProject> subProjects = subProjectRepository.findByProject_ProjectId(project.getProjectId());

        if (!subProjects.isEmpty()) {
            LocalDate startDate = subProjects.stream()
                    .map(SubProject::getStartDate)
                    .min(LocalDate::compareTo)
                    .orElse(null);
            LocalDate endDate = subProjects.stream()
                    .map(SubProject::getEndDate)
                    .max(LocalDate::compareTo)
                    .orElse(null);
            int budget = subProjects.stream()
                    .mapToInt(SubProject::getBudget)
                    .sum();

            project.setStartDate(startDate);
            project.setEndDate(endDate);
            project.setBudget(budget);


            projectRepository.save(project);
        }
    }



    public List<SubProject> getAllSubProjects() {
        return subProjectRepository.findAllWithProjectDetails();
    }




}










