package com.in.generateinvoice.service;

import com.in.generateinvoice.exception.EmployeeNotFoundException;
import com.in.generateinvoice.exception.ProjectNotFoundException;
import com.in.generateinvoice.model.*;
import com.in.generateinvoice.repository.BGTableRepository;
import com.in.generateinvoice.repository.BillGenerateRepository;
import com.in.generateinvoice.repository.ProjectEmployeeRepository;
import com.in.generateinvoice.repository.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class BillGenerateService {


    @Autowired
    private ProjectRepository projectRepository;

    @Autowired
    private ProjectEmployeeRepository projectEmployeeRepository;

    @Autowired
    private BillGenerateRepository billGenerateRepository;
    @Autowired
    ProjectEmployeeService projectEmployeeService;


    @Autowired
    private BGTableRepository bgTableRepository;


    public BillGenerate saveBillGenerateUI(BillGenerateUI billGenerateUI) {

        Project project = projectRepository.findByProjectId(billGenerateUI.getProjectId());

        if (project != null) {

            LocalDate billGenerateStartDate = billGenerateUI.getBillGenerateStartDate();
            LocalDate projectStartDate = project.getStartDate();
            LocalDate projectEndDate = project.getEndDate();

            if (billGenerateStartDate.isAfter(projectStartDate) && billGenerateStartDate.isBefore(projectEndDate)) {

                LocalDate billGenerateEndDate = billGenerateUI.getBillGenerateEndDate();

                if (billGenerateEndDate.isAfter(projectStartDate) && billGenerateEndDate.isBefore(projectEndDate)) {

                    List<ProjectEmployees> projectEmployeesList = projectEmployeeService.getAllProjectEmployeesByProjectId(project.getProjectId());

                    if (!projectEmployeesList.isEmpty()) {

                        BillGenerate billGenerate = new BillGenerate();


                        billGenerate.setProject(project);


                        billGenerate.setBillGenerateStartDate(billGenerateStartDate);
                        billGenerate.setBillGenerateEndDate(billGenerateEndDate);

                        billGenerate = billGenerateRepository.save(billGenerate);


                        for (ProjectEmployees projectEmployee : projectEmployeesList) {
                            BGTable bgTable = new BGTable();
                            bgTable.setBillGenerate(billGenerate);
                            bgTable.setProjectEmployees(projectEmployee);
//                            bgTable.setEmployeeWorkingStartDate(billGenerateStartDate);
//                            bgTable.setEmployeeWorkingEndDate(billGenerateEndDate);

                            // Calculate totalDays, totalAmount, and rate as needed
                            // For simplicity, you can set them to 0 initially and update them later

                            // Save the BGTable entry
                            bgTableRepository.save(bgTable);
                        }

                        return billGenerate;
                    } else {
                        throw new EmployeeNotFoundException("Project is not yet assigned");
                    }
                } else {
                    throw new IllegalArgumentException("billGenerateEndDate is not within project startDate and endDate");
                }
            } else {
                throw new IllegalArgumentException("billGenerateStartDate is not within project startDate and endDate");
            }
        } else {

            throw new ProjectNotFoundException("Project not found");
        }
    }

    public List<BillGenerate> getAllBillGenerates() {
        return billGenerateRepository.findAll();
    }

    public BillGenerate getBillGenerateDatesById(int billGenerateTableId) {
        return billGenerateRepository.findById(billGenerateTableId).orElse(null);
    }
}






























