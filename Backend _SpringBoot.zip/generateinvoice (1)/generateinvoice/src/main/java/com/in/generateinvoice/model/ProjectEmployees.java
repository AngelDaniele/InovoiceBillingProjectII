package com.in.generateinvoice.model;

import javax.persistence.*;

@Entity
@Table(name="ProjectEmployees")
public class ProjectEmployees {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="projectEmployeeId")
    private int projectEmployeeId;


    @ManyToOne
    @JoinColumn(name = "employeeTableId")
    private Employee employee;

    @ManyToOne
    @JoinColumn(name = "projectTableId")
    private Project project;


    public int getProjectEmployeeId() {
        return projectEmployeeId;
    }

    public void setProjectEmployeeId(int projectEmployeeId) {
        this.projectEmployeeId = projectEmployeeId;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }
}

