package com.in.generateinvoice.service;

import com.in.generateinvoice.model.BGTable;
import com.in.generateinvoice.model.BillGenerate;
import com.in.generateinvoice.repository.BGTableRepository;
import com.in.generateinvoice.repository.BillGenerateRepository;
import com.in.generateinvoice.repository.ProjectEmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.Optional;

@Service
public class BGTableService {


        @Autowired
        private BGTableRepository bgTableRepository;

        @Autowired
        private BillGenerateRepository billGenerateRepository;

        @Autowired
        private ProjectEmployeeRepository projectEmployeeRepository;

    public BGTable updateBGTable(int bgTableId, int billGenerateTableId, BGTable updatedBGTable) {

        Optional<BGTable> existingBGTableOptional = bgTableRepository.findById(bgTableId);

        if (existingBGTableOptional.isPresent()) {
            BGTable existingBGTable = existingBGTableOptional.get();


            if (existingBGTable.getBillGenerate().getBillGenerateTableId() == billGenerateTableId) {

                existingBGTable.setEmployeeWorkingStartDate(updatedBGTable.getEmployeeWorkingStartDate());
                existingBGTable.setEmployeeWorkingEndDate(updatedBGTable.getEmployeeWorkingEndDate());
                existingBGTable.setTotalDays(updatedBGTable.getTotalDays());
                existingBGTable.setRate(updatedBGTable.getRate());
                existingBGTable.setTotalAmount(updatedBGTable.getTotalAmount());


                return bgTableRepository.save(existingBGTable);
            } else {
                throw new IllegalArgumentException("billGenerateTableId does not match the existing record");
            }
        } else {
            throw new EntityNotFoundException("BGTable not found");
        }
    }




    private BillGenerate getBillGenerate(int billGenerateTableId) {

        Optional<BillGenerate> optionalBillGenerate = billGenerateRepository.findById(billGenerateTableId);

        if (optionalBillGenerate.isPresent()) {
            return optionalBillGenerate.get();
        } else {
            return null;
        }
    }


    public List<BGTable> getAllBGTable() {
        return bgTableRepository.findAll();
    }


    public List<BGTable> getAllBGTablesByBillGenerateTableId(int billGenerateTableId) {
        return bgTableRepository.findAllByBillGenerate_BillGenerateTableId(billGenerateTableId);
    }

        }


