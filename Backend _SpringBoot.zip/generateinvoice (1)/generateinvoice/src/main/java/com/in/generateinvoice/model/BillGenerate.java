package com.in.generateinvoice.model;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "BillGenerate")
public class BillGenerate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "billGenerateTableId")
    private int billGenerateTableId;

    @ManyToOne
    @JoinColumn(name = "projectTableId")
    private Project project;



    @ManyToOne
    @JoinColumn(name = "projectEmployeeId")
    private ProjectEmployees projectEmployees;

    @Column(name = "billGenerateStartDate")
    private LocalDate billGenerateStartDate;

    @Column(name = "billGenerateEndDate")
    private LocalDate billGenerateEndDate;

    public BillGenerate() {
    }

    public int getBillGenerateTableId() {
        return billGenerateTableId;
    }

    public void setBillGenerateTableId(int billGenerateTableId) {
        this.billGenerateTableId = billGenerateTableId;
    }

    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }




    public ProjectEmployees getProjectEmployees() {
        return projectEmployees;
    }

    public void setProjectEmployees(ProjectEmployees projectEmployees) {
        this.projectEmployees = projectEmployees;
    }

    public LocalDate getBillGenerateStartDate() {
        return billGenerateStartDate;
    }

    public void setBillGenerateStartDate(LocalDate billGenerateStartDate) {
        this.billGenerateStartDate = billGenerateStartDate;
    }

    public LocalDate getBillGenerateEndDate() {
        return billGenerateEndDate;
    }

    public void setBillGenerateEndDate(LocalDate billGenerateEndDate) {
        this.billGenerateEndDate = billGenerateEndDate;
    }
}







