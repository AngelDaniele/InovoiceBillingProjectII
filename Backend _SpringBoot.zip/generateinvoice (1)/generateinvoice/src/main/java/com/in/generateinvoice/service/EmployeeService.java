package com.in.generateinvoice.service;

import com.in.generateinvoice.exception.ClientNotFoundException;
import com.in.generateinvoice.exception.EmployeeNotFoundException;
import com.in.generateinvoice.model.Employee;
import com.in.generateinvoice.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService {

    @Autowired
    EmployeeRepository employeeRepository;

    public Employee saveEmployee(Employee employee) {

        return employeeRepository.save(employee);

    }



    public List<Employee> getAllEmployee() {

        List<Employee> list = employeeRepository.findAll();

        if (list.size() > 0) {
            return list;
        } else
            throw new ClientNotFoundException("No Client in catalog");
    }

    public Employee updateEmployee(Employee employee, int key) throws EmployeeNotFoundException {
        Optional<Employee> optionalEmployee = employeeRepository.findById(key);

        if (optionalEmployee.isPresent()) {
           Employee existingEmployee = optionalEmployee.get();
            existingEmployee.setEmployeeId(employee.getEmployeeId());
            existingEmployee.setEmployeeName(employee.getEmployeeName());
            existingEmployee.setDesignation(employee.getDesignation());
            existingEmployee.setAddress(employee.getAddress());
            existingEmployee.setEducationalQualification(employee.getEducationalQualification());

            Employee updatedEmployee = employeeRepository.save(existingEmployee);
            return updatedEmployee;
        } else {
            throw new EmployeeNotFoundException("Employee not found with the given id");
        }
    }


    public String deleteEmployee(Integer id) throws EmployeeNotFoundException{

        Optional<Employee> opt=	employeeRepository.findById(id);

        if(opt.isPresent()) {
            Employee employee = opt.get();
            employeeRepository.delete(employee);
            return "Employee deleted";
        } else
            throw new EmployeeNotFoundException("Employee not found with given id");
    }


}
