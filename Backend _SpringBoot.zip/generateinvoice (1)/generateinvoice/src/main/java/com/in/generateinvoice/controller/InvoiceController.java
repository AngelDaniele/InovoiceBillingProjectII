package com.in.generateinvoice.controller;

import com.in.generateinvoice.model.Invoice;
import com.in.generateinvoice.service.InvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/invoices")
public class InvoiceController {



        @Autowired
        private InvoiceService invoiceService;

        @PostMapping("/generate/{billGenerateTableId}")
        public ResponseEntity<Object> generateInvoice(@PathVariable int billGenerateTableId) {

                Invoice invoice = invoiceService.createInvoice(billGenerateTableId);
                return new ResponseEntity<>(invoice, HttpStatus.CREATED);

        }

        @GetMapping("/retrieve/{billGenerateTableId}")
        public ResponseEntity<Object> retrieveInvoice(@PathVariable int billGenerateTableId) {
                Invoice invoice = invoiceService.getInvoiceByBillGenerateTableId(billGenerateTableId);

                if (invoice != null) {
                        return new ResponseEntity<>(invoice, HttpStatus.OK);
                } else {
                        return new ResponseEntity<>("Invoice not found", HttpStatus.NOT_FOUND);
                }
        }









}






