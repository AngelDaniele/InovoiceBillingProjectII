package com.in.generateinvoice.controller;

import com.in.generateinvoice.model.BGTable;
import com.in.generateinvoice.service.BGTableService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/bgtable")
public class BGTableController {
@Autowired
BGTableService bgTableService;


    @PostMapping("/update/{bgTableId}/{billGenerateTableId}")
    public ResponseEntity<BGTable> updateBGTable(
            @PathVariable int bgTableId,
            @PathVariable int billGenerateTableId,
            @RequestBody BGTable updatedBGTable) {

        BGTable result = bgTableService.updateBGTable(bgTableId, billGenerateTableId, updatedBGTable);
        return new ResponseEntity<>(result, HttpStatus.OK);
    }



    @GetMapping("/all")
    public ResponseEntity<List<BGTable>> getAllBGTable() {
        List<BGTable> bgTables = bgTableService.getAllBGTable();
        return ResponseEntity.ok(bgTables);
    }

    @GetMapping("/by-bill-generate/{billGenerateTableId}")
    public ResponseEntity<List<BGTable>> getAllBGTablesByBillGenerateTableId(@PathVariable int billGenerateTableId) {
        List<BGTable> bgTables = bgTableService.getAllBGTablesByBillGenerateTableId(billGenerateTableId);
        return new ResponseEntity<>(bgTables, HttpStatus.OK);
    }
}
