package com.in.generateinvoice.model;

import java.time.LocalDate;

public class BGTableClient {





  private  LocalDate employeeWorkingStartDate;
    private LocalDate employeeWorkingEndDate;
     private int totalDays;
    private int rate;
     private int totalAmount;



    public LocalDate getEmployeeWorkingStartDate() {
        return employeeWorkingStartDate;
    }

    public void setEmployeeWorkingStartDate(LocalDate employeeWorkingStartDate) {
        this.employeeWorkingStartDate = employeeWorkingStartDate;
    }

    public LocalDate getEmployeeWorkingEndDate() {
        return employeeWorkingEndDate;
    }

    public void setEmployeeWorkingEndDate(LocalDate employeeWorkingEndDate) {
        this.employeeWorkingEndDate = employeeWorkingEndDate;
    }

    public int getTotalDays() {
        return totalDays;
    }

    public void setTotalDays(int totalDays) {
        this.totalDays = totalDays;
    }

    public int getRate() {
        return rate;
    }

    public void setRate(int rate) {
        this.rate = rate;
    }

    public int getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(int totalAmount) {
        this.totalAmount = totalAmount;
    }
}
