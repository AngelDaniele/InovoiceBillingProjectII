package com.in.generateinvoice.repository;

import com.in.generateinvoice.model.BillGenerate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BillGenerateRepository extends JpaRepository<BillGenerate,Integer> {




}
