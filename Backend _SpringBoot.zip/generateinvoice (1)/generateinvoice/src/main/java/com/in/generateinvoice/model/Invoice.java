package com.in.generateinvoice.model;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "Invoice")
public class Invoice {




        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "invoiceNumber")
        private int invoiceNumber;

        @Column(name = "billGenerateTableId")
        private int billGenerateTableId;

        @Column(name = "cgst")
        private BigDecimal cgst;

        @Column(name = "sgst")
        private BigDecimal sgst;

        @Column(name = "subtotal")
        private BigDecimal subtotal;

        @Column(name = "totalAmount")
        private BigDecimal totalAmount;

        // Getters and setters

        public int getInvoiceNumber() {
            return invoiceNumber;
        }

        public void setInvoiceNumber(int invoiceNumber) {
            this.invoiceNumber = invoiceNumber;
        }

        public int getBillGenerateTableId() {
            return billGenerateTableId;
        }

        public void setBillGenerateTableId(int billGenerateTableId) {
            this.billGenerateTableId = billGenerateTableId;
        }

        public BigDecimal getCgst() {
            return cgst;
        }

        public void setCgst(BigDecimal cgst) {
            this.cgst = cgst;
        }

        public BigDecimal getSgst() {
            return sgst;
        }

        public void setSgst(BigDecimal sgst) {
            this.sgst = sgst;
        }

        public BigDecimal getSubtotal() {
            return subtotal;
        }

        public void setSubtotal(BigDecimal subtotal) {
            this.subtotal = subtotal;
        }

        public BigDecimal getTotalAmount() {
            return totalAmount;
        }

        public void setTotalAmount(BigDecimal totalAmount) {
            this.totalAmount = totalAmount;
        }
    }


