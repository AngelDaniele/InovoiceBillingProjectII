package com.in.generateinvoice.controller;

import com.in.generateinvoice.model.DesignationSummary;
import com.in.generateinvoice.service.DesignationSummaryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/designation-summary")
public class DesignationSummaryController {

    @Autowired
    private DesignationSummaryService designationSummaryService;

    @PostMapping("/calculate-and-save/{billGenerateTableId}")
    public List<DesignationSummary> calculateAndSaveDesignationSummary(@PathVariable int billGenerateTableId) {
        List<DesignationSummary> savedDesignationSummaries = designationSummaryService.calculateAndSaveDesignationSummary(billGenerateTableId);
        return savedDesignationSummaries;
    }


    @GetMapping("/{billGenerateTableId}")
    public List<DesignationSummary> getDesignationSummariesByBillGenerateTableId(@PathVariable int billGenerateTableId) {
        return designationSummaryService.getDesignationSummariesByBillGenerateTableId(billGenerateTableId);
    }

}
