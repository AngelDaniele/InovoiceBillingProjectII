package com.in.generateinvoice.service;

import com.in.generateinvoice.model.*;
import com.in.generateinvoice.repository.BGTableRepository;
import com.in.generateinvoice.repository.DesignationSummaryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class DesignationSummaryService {


   @Autowired
        private BGTableRepository bgTableRepository;
        @Autowired
        private DesignationSummaryRepository designationSummaryRepository;

//    public List<DesignationSummary> calculateAndSaveDesignationSummary(int billGenerateTableId) {
//        List<BGTable> bgTableEntries = bgTableRepository.findAllByBillGenerate_BillGenerateTableId(billGenerateTableId);
//
//        // Create a map to store designation-wise statistics
//        Map<String, DesignationSummary> designationSummaryMap = new HashMap<>();
//
//        // Iterate through BGTable entries and calculate statistics
//        for (BGTable bgTableEntry : bgTableEntries) {
//            ProjectEmployees projectEmployees = bgTableEntry.getProjectEmployees();
//            Employee employee = projectEmployees.getEmployee();
//            String designation = employee.getDesignation();
//            int rate = bgTableEntry.getRate();
//            int totalAmount = bgTableEntry.getTotalAmount();
//
//            // Check if a DesignationSummary exists for this designation
//            if (designationSummaryMap.containsKey(designation)) {
//                DesignationSummary existingSummary = designationSummaryMap.get(designation);
//                existingSummary.setNumberOfEmployees(existingSummary.getNumberOfEmployees() + 1);
//                existingSummary.setTotalRate(existingSummary.getTotalRate() + rate);
//
//                // Ensure totalAmount does not exceed the project's budget
//                Project project = projectEmployees.getProject();
//                int projectBudget = project.getBudget();
//                if (existingSummary.getTotalAmount() + totalAmount <= projectBudget) {
//                    existingSummary.setTotalAmount(existingSummary.getTotalAmount() + totalAmount);
//                } else {
//                    existingSummary.setTotalAmount(projectBudget);
//                }
//            } else {
//                // Create a new DesignationSummary if it doesn't exist
//                DesignationSummary newSummary = new DesignationSummary();
//                newSummary.setBillGenerateTableId(billGenerateTableId);
//                newSummary.setDesignation(designation);
//                newSummary.setNumberOfEmployees(1);
//                newSummary.setTotalRate(rate);
//
//                // Ensure totalAmount does not exceed the project's budget
//                Project project = projectEmployees.getProject();
//                int projectBudget = project.getBudget();
//                if (totalAmount <= projectBudget) {
//                    newSummary.setTotalAmount(totalAmount);
//                } else {
//                    newSummary.setTotalAmount(projectBudget);
//                }
//
//                designationSummaryMap.put(designation, newSummary);
//            }
//        }

        // Now you have updated DesignationSummary objects in designationSummaryMap.
        // You can save them or return them as needed.



        public List<DesignationSummary> calculateAndSaveDesignationSummary(int billGenerateTableId) {
            List<BGTable> bgTableEntries = bgTableRepository.findAllByBillGenerate_BillGenerateTableId(billGenerateTableId);


            Map<String, DesignationSummary> designationSummaryMap = new HashMap<>();


            for (BGTable bgTableEntry : bgTableEntries) {
                ProjectEmployees projectEmployees = bgTableEntry.getProjectEmployees();
                Employee employee = projectEmployees.getEmployee();
                String designation = employee.getDesignation();
                int rate = bgTableEntry.getRate();
                int totalAmount = bgTableEntry.getTotalAmount();


                if (designationSummaryMap.containsKey(designation)) {
                    DesignationSummary existingSummary = designationSummaryMap.get(designation);
                    existingSummary.setNumberOfEmployees(existingSummary.getNumberOfEmployees() + 1);
                    existingSummary.setTotalRate(existingSummary.getTotalRate() + rate);
                    existingSummary.setTotalAmount(existingSummary.getTotalAmount() + totalAmount);
                } else {

                    DesignationSummary newSummary = new DesignationSummary();
                    newSummary.setBillGenerateTableId(billGenerateTableId);
                    newSummary.setDesignation(designation);
                    newSummary.setNumberOfEmployees(1);
                    newSummary.setTotalRate(rate);
                    newSummary.setTotalAmount(totalAmount);

                    designationSummaryMap.put(designation, newSummary);
                }
            }


            List<DesignationSummary> savedDesignationSummaries = designationSummaryRepository.saveAll(designationSummaryMap.values());

            return savedDesignationSummaries;
        }

    public List<DesignationSummary> getDesignationSummariesByBillGenerateTableId(int billGenerateTableId) {
        return designationSummaryRepository.findByBillGenerateTableId(billGenerateTableId);
    }
    }






