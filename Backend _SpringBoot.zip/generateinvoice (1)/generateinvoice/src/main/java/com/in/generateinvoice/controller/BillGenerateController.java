package com.in.generateinvoice.controller;

import com.in.generateinvoice.model.BillGenerate;
import com.in.generateinvoice.model.BillGenerateUI;
import com.in.generateinvoice.service.BillGenerateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api/billgenerate")
public class BillGenerateController {


    @Autowired
    private BillGenerateService billGenerateService;

    @PostMapping("/create")
    public ResponseEntity<BillGenerate> createBillGenerate(@RequestBody BillGenerateUI billGenerateUI) {

            BillGenerate savedBillGenerate = billGenerateService.saveBillGenerateUI(billGenerateUI);
            return ResponseEntity.ok(savedBillGenerate);

    }

    @GetMapping("/all")
    public ResponseEntity<List<BillGenerate>> getAllBillGenerates() {
        List<BillGenerate> billGenerates = billGenerateService.getAllBillGenerates();
        return ResponseEntity.ok(billGenerates);
    }

    @GetMapping("/{billGenerateTableId}/dates")
    public ResponseEntity<BillGenerate> getBillGenerateDates(@PathVariable int billGenerateTableId) {
        BillGenerate billGenerate = billGenerateService.getBillGenerateDatesById(billGenerateTableId);

        if (billGenerate != null) {
            return ResponseEntity.ok(billGenerate);
        } else {
            // Handle the case where the specified billGenerateTableId was not found
            return ResponseEntity.notFound().build();
        }
    }
}




