package com.in.generateinvoice.service;

import com.in.generateinvoice.exception.InvalidCredentialsException;
import com.in.generateinvoice.exception.UserAlreadyExists;
import com.in.generateinvoice.model.ProjectManager;
import com.in.generateinvoice.model.ProjectManagerLoginDTO;
import com.in.generateinvoice.repository.ProjectManagerRepository;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProjectManagerService {


    @Autowired
    private ProjectManagerRepository projectManagerRepository;

    public ProjectManager saveProjectManager(ProjectManager projectManager) {
        ProjectManager projectManager1 = projectManagerRepository.findByProjectManagerLoginId(projectManager.getProjectManagerLoginId());
        if (projectManager1  == null) {
            String password = projectManager.getProjectManagerPassword();
            String hashedPassword = hashPassword(password);
            projectManager.setProjectManagerPassword(hashedPassword);
            return projectManagerRepository.save(projectManager);
        } else {
            throw new UserAlreadyExists("User Already Exists");
        }
    }



    private String hashPassword(String password) {

        String hashedPassword = DigestUtils.sha256Hex(password);

        return hashedPassword;
    }


    public  ProjectManager loginProjectManager(ProjectManagerLoginDTO loginDTO) {
        ProjectManager projectManager = projectManagerRepository.findByProjectManagerLoginId(loginDTO.getProjectManagerLoginId());
        if (projectManager != null) {
            String storedHashedPassword = projectManager.getProjectManagerPassword();
            String providedPassword = loginDTO.getProjectManagerPassword();

            if (isPasswordMatch(providedPassword, storedHashedPassword)) {
                return projectManager;
            }
        }
        throw new InvalidCredentialsException("Invalid credentials");
    }

    private boolean isPasswordMatch(String providedPassword, String storedHashedPassword) {
        String hashedProvidedPassword = hashPassword(providedPassword);
        return hashedProvidedPassword.equals(storedHashedPassword);
    }

}
