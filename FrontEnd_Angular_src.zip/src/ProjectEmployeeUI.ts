export class ProjectEmployeesUI{
    constructor(
     
      public projectId:string,
      public employeeId:string
      
    ) {}
  }
