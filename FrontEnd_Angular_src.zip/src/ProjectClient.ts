export class ProjectClients{
    constructor(
     
      public projectId:string,
      public projectName:string,
      public startDate:string, // Set the default value to an empty date
    public endDate: string,
      public budget:number,
      public clientId:string
      
    ) {}
  }