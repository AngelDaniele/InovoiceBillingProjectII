import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-list-employee',
  templateUrl: './list-employee.component.html',
  styleUrls: ['./list-employee.component.css']
})
export class ListEmployeeComponent implements OnInit{

  employees:any;
  

  constructor(private employeeService: EmployeeService, private router: Router) { }
  ngOnInit(): void {
    this.getEmployeeList();
  }

  getEmployeeList(): void {
    this.employeeService.getEmployeeList().subscribe(employees => this.employees = employees);
  }

  updateEmployee(employeeTableId: number): void {
    this.router.navigate(['/updateEmployee', employeeTableId]);
  }


  deleteEmployee(employeeTableId: number): void {
    this.employeeService.deleteEmployee(employeeTableId).subscribe(() => {
     this.employees = this.employees .filter((employee: any) => employee.employeeTableId !== employeeTableId);
     this.getEmployeeList();
     });
   }
}

