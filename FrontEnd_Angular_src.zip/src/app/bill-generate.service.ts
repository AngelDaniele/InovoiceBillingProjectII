import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BillGenerateUIS } from './bill-generate/BillGenerateUI';
import { Observable } from 'rxjs';
import { BillGenerates } from './bill-generate/BillGenerate';
import { BGTables } from './BGTable';
import { BGTableClients } from './BGTableClient';
import { UpdateBGTable } from './bill-generate/UpdateBGTable';
import { DesignationSummarys } from './bill-generate-final/DesignationSummary';
import { Invoices } from './bill-generate-final/Invoice';


@Injectable({
  providedIn: 'root'
})
export class BillGenerateService {
  billGenerateUIS:any;
  bgTables:any;
 
  constructor(private http: HttpClient) { }


  saveBillGenerateUI(billGenerateUIS: BillGenerateUIS): Observable<any> {
    return this.http.post("http://localhost:8080/api/billgenerate/create", billGenerateUIS);
  }


  getAllBGTable(): Observable<any> {
    return this.http.get("http://localhost:8080/bgtable/all");
  }

getBillGenerateById(billGenerateTableId:number): Observable<BillGenerates> {
  return this.http.get<BillGenerates>(`http://localhost:8080/api/billgenerate/${billGenerateTableId}/dates`);
}
   

// getAllBGTablesByBillGenerateTableId(billGenerateTableId:number): Observable<BGTables> {
//   return this.http.get<BGTables>(`http://localhost:8080/bgtable/by-bill-generate/${billGenerateTableId}`);
// }

getAllBGTablesByBillGenerateTableId(billGenerateTableId: number): Observable<BGTables[]> {
  return this.http.get<BGTables[]>(`http://localhost:8080/bgtable/by-bill-generate/${billGenerateTableId}`);
}



updateBGTable(bgTableId:number,billGenerateTableId: number, bgTable: BGTables): Observable<any> {
  return this.http.post(`http://localhost:8080/bgtable/update/${bgTableId}/${billGenerateTableId}`, bgTable);
}


calculateAndSaveDesignationSummary(billGenerateTableId: number,designationSummary:DesignationSummarys): Observable<any> {
  return this.http.post(`http://localhost:8080/designation-summary/calculate-and-save/${billGenerateTableId}`, designationSummary);
}

getDesignationSummariesByBillGenerateTableId(billGenerateTableId: number): Observable<DesignationSummarys> {
  return this.http.get<DesignationSummarys>(`http://localhost:8080/designation-summary/${billGenerateTableId}`);

  

}


createInvoice(billGenerateTableId: number,invoice:Invoices): Observable<any> {
  return this.http.post(`http://localhost:8080/invoices/generate/${billGenerateTableId}`,invoice);
}

getInvoiceByBillGenerateTableId(billGenerateTableId: number): Observable<Invoices> {
  return this.http.get<Invoices>(`http://localhost:8080/invoices/retrieve/${billGenerateTableId}`);

  

}


}