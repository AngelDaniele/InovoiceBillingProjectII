import { Component, OnInit } from '@angular/core';
import { BillGenerateUIS } from './BillGenerateUI';
import { ProjectService } from '../project.service';
import { Router } from '@angular/router';
import { BillGenerateService } from '../bill-generate.service';


@Component({
  selector: 'app-bill-generate',
  templateUrl: './bill-generate.component.html',
  styleUrls: ['./bill-generate.component.css']
})
export class BillGenerateComponent implements OnInit{
   billGenerateUIS : BillGenerateUIS = new BillGenerateUIS("",new Date(),new Date());
  projects:any;
  loginFailed = false;
 

  constructor(private projectService: ProjectService, private router: Router,private billGenerateService: BillGenerateService ) { }
  ngOnInit(): void {
    this.getProjectList();
  }


  getProjectList(): void {
    this.projectService.getProjectList().subscribe(projects => this.projects = projects);
  }


  onSubmit() {
    console.log(this.billGenerateUIS);
    this.saveBillGenerate();

  }

  saveBillGenerate() {
    this.billGenerateService.saveBillGenerateUI(this.billGenerateUIS).subscribe(
      data => {
        console.log(data);
        this.goToBillGenerateList(data.billGenerateTableId);
      },
      error => {
        console.log(error);
         this.loginFailed = true;
        
      }
    );

}
 
goToBillGenerateList(billGenerateTableId: number) {
  this.router.navigate(['/billgeneratelist', billGenerateTableId]);
}

}

