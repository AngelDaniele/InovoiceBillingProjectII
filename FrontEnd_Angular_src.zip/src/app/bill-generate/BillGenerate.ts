import { Projects } from "src/Project";
import { ProjectEmployees } from "src/ProjectEmployees";


export class BillGenerates {

    
    billGenerateTableId!:number;
    project!: Projects;
    projectEmployees!: ProjectEmployees;
    billGenerateStartDate!: Date;
    billGenerateEndDate!: Date;
   
    

}