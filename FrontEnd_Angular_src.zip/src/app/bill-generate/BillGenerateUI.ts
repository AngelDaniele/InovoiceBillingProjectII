export class BillGenerateUIS{
    constructor(
     
      public projectId:string,
      public billGenerateStartDate:Date,
    public billGenerateEndDate: Date
  
      
    ) {}
  } 