import { Projects } from "src/Project";
import { ProjectEmployees } from "src/ProjectEmployees";
import { BillGenerates } from "./BillGenerate";

export class UpdateBGTable{
    
    bgTableId!:number;
    billGenerate!: BillGenerates;
    projectEmployees!: ProjectEmployees;
    employeeWorkingStartDate!: Date;
    employeeWorkingEndDate!: Date;
    totalDays!: number;
    totalAmount!: number;
    rate!: number;

}