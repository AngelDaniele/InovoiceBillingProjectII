import { Component } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router';
import { Employees } from '../Employee';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent {
  employee: Employees = new Employees();
  loginFailed = false;

  constructor(private employeeService: EmployeeService, private router: Router) { }


 

 

  onSubmit() {
    console.log(this.employee);
    this.saveEmployee();
  }

  saveEmployee() {
    this.employeeService.createEmployee(this.employee).subscribe(
      data => {
        console.log(data);
        this.goToEmployeeList();
      },
      error => {
        console.log(error);
        this.loginFailed = true;
      }
    );
  }

  goToEmployeeList() {
    this.router.navigate(['/employeelist']);
  }

}
