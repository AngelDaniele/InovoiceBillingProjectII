import { Component, OnInit } from '@angular/core';
import { BGTableClients } from '../BGTableClient';
import { BillGenerateService } from '../bill-generate.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { BillGenerateUIS } from '../bill-generate/BillGenerateUI';
import { BillGenerates } from '../bill-generate/BillGenerate';
import { BGTables } from '../BGTable';
import { UpdateBGTable } from '../bill-generate/UpdateBGTable';
import { ProjectEmployees } from 'src/ProjectEmployees';
@Component({
  selector: 'app-bill-generate-list',
  templateUrl: './bill-generate-list.component.html',
  styleUrls: ['./bill-generate-list.component.css']
})
export class BillGenerateListComponent implements OnInit  {

  clientForm!: FormGroup;
  bGTableClient :BGTableClients = new BGTableClients(new Date(),new Date(),0,0,0);
  bGTableClients:any;
  billGenerateTableId=0;
  bgTableId=0;
  updateBGTable:UpdateBGTable = new UpdateBGTable();
 bgTable :BGTables= new BGTables();
  billGenerateUIS : BillGenerateUIS = new BillGenerateUIS("",new Date(),new Date());
billGenerates:BillGenerates= new BillGenerates();
updateBGTables:UpdateBGTable [] = [];

bgTables: BGTables[] = [];

  constructor(private route: ActivatedRoute,private billGenerateService: BillGenerateService, private router: Router) { }
  ngOnInit(): void {
    this.route.params.subscribe(params => {
      const billGenerateTableId = +params['billGenerateTableId'];
      this.billGenerateTableId = billGenerateTableId;
       // + converts the string to a number
       this.bgTable = new BGTables(); 
   
       console.log('billGenerateTableId:', billGenerateTableId);
      this.getBillGenerateDataById(billGenerateTableId);
      this. getAllBGTablesByBillGenerateTableId(billGenerateTableId);
      
    });
   
  }

  getBillGenerateDataById(billGenerateTableId: number): void {
    this.billGenerateService.getBillGenerateById(billGenerateTableId).subscribe(
      billGenerates => {
        this.billGenerates = billGenerates;
        // console.log(this.billGenerates);
      },
      error => {
        console.log(error);
        // Handle error if needed
      }
    );
  }

  getAllBGTablesByBillGenerateTableId(billGenerateTableId: number): void {
    this.billGenerateService.getAllBGTablesByBillGenerateTableId(billGenerateTableId).subscribe(
      response => {
        this.bgTables = response; // Assign the response directly if it's an array of BGTables
      },
      error => {
        console.log(error);
        // Handle error if needed
      }
    );
  }
  addMissingFields(bgTable: BGTables): void {
    // Create and initialize a new BGTables object with default values
    const newBGTable: BGTables = {
      bgTableId: 0,
      employeeWorkingStartDate: new Date(),
      employeeWorkingEndDate: new Date(),
      totalDays: 0,
      rate: 0,
      totalAmount: 0,
      billGenerate: new BillGenerates,
      projectEmployees: new ProjectEmployees
    };
  
    // Add the new BGTables object to the array
    this.bgTables.push(newBGTable);
  }
  calculateTotalDays(bgTable: any) {
    if (bgTable.employeeWorkingStartDate && bgTable.employeeWorkingEndDate) {
      const startDate = new Date(bgTable.employeeWorkingStartDate);
      const endDate = new Date(bgTable.employeeWorkingEndDate);
      const timeDifference = endDate.getTime() - startDate.getTime();
      const totalDays = timeDifference / (1000 * 60 * 60 * 24); // Calculate days
      bgTable.totalDays = totalDays;
    }
  }
  
  
  insertOrUpdateBGTableEntry(bgTableId: number, billGenerateTableId: number, updatedBGTable: BGTables): void {
    this.billGenerateService.updateBGTable(bgTableId, billGenerateTableId, updatedBGTable).subscribe(
      bgTable => {
        console.log('Updated BGTable data:', bgTable)
        this.getBillGenerateList(billGenerateTableId);
      },
      error => {
        console.log(error);
        console.log(billGenerateTableId);
        console.log(bgTableId);
      }
    );
  }

  getBillGenerateList(billGenerateTableId: number): void {
    this.router.navigate(['/BillGenerateList',billGenerateTableId]);
  }

  
  calculateTotalAmount(bgTable: any) {
    if (bgTable.rate && bgTable.totalDays) {
      bgTable.totalAmount = bgTable.rate * bgTable.totalDays;
    }
  }

  onSubmit(): void {
    this.insertOrUpdateBGTables(this.billGenerateTableId, this.bgTables);
  }
  
  insertOrUpdateBGTables(billGenerateTableId: number, bgTables: BGTables[]): void {
    // Iterate through the bgTables array and call the insertOrUpdateBGTableEntry method for each BGTables object
    bgTables.forEach((bgTable: BGTables) => {
      this.insertOrUpdateBGTableEntry(bgTable.bgTableId, billGenerateTableId, bgTable);
    });
  }
}
