import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BillGenerateListComponent } from './bill-generate-list.component';

describe('BillGenerateListComponent', () => {
  let component: BillGenerateListComponent;
  let fixture: ComponentFixture<BillGenerateListComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [BillGenerateListComponent]
    });
    fixture = TestBed.createComponent(BillGenerateListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
