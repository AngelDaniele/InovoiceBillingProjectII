export class SubProjectUIS{
    constructor(
     
      public subProjectId:string,
      public startDate:Date,
    public endDate: Date,
      public budget:number,
      public projectId:string
      
    ) {}
  } 