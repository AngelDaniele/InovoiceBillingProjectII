import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubprojectlistComponent } from './subprojectlist.component';

describe('SubprojectlistComponent', () => {
  let component: SubprojectlistComponent;
  let fixture: ComponentFixture<SubprojectlistComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SubprojectlistComponent]
    });
    fixture = TestBed.createComponent(SubprojectlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
