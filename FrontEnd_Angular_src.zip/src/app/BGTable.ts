import { ProjectEmployees } from "src/ProjectEmployees";
import { BillGenerates } from "./bill-generate/BillGenerate";

export class BGTables {
    
    bgTableId!:number;
    billGenerate!: BillGenerates;
    projectEmployees!: ProjectEmployees;
    employeeWorkingStartDate!: Date;
    employeeWorkingEndDate!: Date;
    totalDays!: number;
    totalAmount!: number;
    rate!: number;
   
   }
  