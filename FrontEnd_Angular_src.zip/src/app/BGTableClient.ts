export class BGTableClients{
    constructor(
     
    
      public employeeWorkingStartDate:Date,
      public employeeWorkingEndDate:Date, // Set the default value to an empty date
    public totalDays: number,
      public rate:number,
      public totalAmount:number
      
    ) {}
  }