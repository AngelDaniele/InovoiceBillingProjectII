export class UpdateClient {
    
    clientTableId!:number;
    clientId!: string;
    clientName!: string;
    clientAddress!: string;
    phoneNumber!: string;
    gmailId!: string;
   

}
