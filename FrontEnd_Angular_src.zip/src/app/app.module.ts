import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ProjectManagerComponent } from './project-manager/project-manager.component';
import { ClientComponent } from './client/client.component';
import { ClientListComponent } from './client-list/client-list.component';
import { UpdateclientComponent } from './updateclient/updateclient.component';
import { EmployeeComponent } from './employee/employee.component';

import { ListEmployeeComponent } from './list-employee/list-employee.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';
import { ProjectComponent } from './project/project.component';
import { ProjectListComponent } from './project-list/project-list.component';
import { ProjectEmployeeComponent } from './project-employee/project-employee.component';
import { SubProjectComponent } from './sub-project/sub-project.component';
import { SubprojectlistComponent } from './subprojectlist/subprojectlist.component';
import { ProjectEmployeeListComponent } from './project-employee-list/project-employee-list.component';
import { BillGenerateComponent } from './bill-generate/bill-generate.component';
import { BillGenerateListComponent } from './bill-generate-list/bill-generate-list.component';
import { BillGenerateUpdateComponent } from './bill-generate-update/bill-generate-update.component';
import { BillGenerateFinalComponent } from './bill-generate-final/bill-generate-final.component';
import { BillGenerateEditComponent } from './bill-generate-edit/bill-generate-edit.component';



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ProjectManagerComponent,
    ClientComponent,
    ClientListComponent,
    UpdateclientComponent,
    EmployeeComponent,
    ListEmployeeComponent,
    UpdateEmployeeComponent,
    ProjectComponent,
    ProjectListComponent,
    ProjectEmployeeComponent,
    SubProjectComponent,
    SubprojectlistComponent,
    ProjectEmployeeListComponent,
    BillGenerateComponent,
    BillGenerateListComponent,
    BillGenerateUpdateComponent,
    BillGenerateFinalComponent,
    BillGenerateEditComponent,
    
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
