import { Component, OnInit } from '@angular/core';
import { BillGenerateService } from '../bill-generate.service';
import { ActivatedRoute, Router } from '@angular/router';
import { BGTables } from '../BGTable';
import { BillGenerates } from '../bill-generate/BillGenerate';

@Component({
  selector: 'app-bill-generate-update',
  templateUrl: './bill-generate-update.component.html',
  styleUrls: ['./bill-generate-update.component.css']
})
export class BillGenerateUpdateComponent implements OnInit {

  billGenerateTableId=0;
  billGenerates:BillGenerates= new BillGenerates();
  bgTables: BGTables[] = [];
  bgTable :BGTables= new BGTables();
  constructor(private route: ActivatedRoute,private billGenerateService: BillGenerateService, private router: Router) { }
  ngOnInit(): void {
    this.route.params.subscribe(params => {
      const billGenerateTableId = +params['billGenerateTableId'];
      this.billGenerateTableId = billGenerateTableId;
      console.log('billGenerateTableId:', billGenerateTableId);
      this.getBillGenerateDataById(billGenerateTableId);
      this. getAllBGTablesByBillGenerateTableId(billGenerateTableId);
    });
  }
  getBillGenerateDataById(billGenerateTableId: number): void {
    this.billGenerateService.getBillGenerateById(billGenerateTableId).subscribe(
      billGenerates => {
        this.billGenerates = billGenerates;
        // console.log(this.billGenerates);
      },
      error => {
        console.log(error);
        // Handle error if needed
      }
    );
  }

  getAllBGTablesByBillGenerateTableId(billGenerateTableId: number): void {
    this.billGenerateService.getAllBGTablesByBillGenerateTableId(billGenerateTableId).subscribe(
      response => {
        this.bgTables = response; // Assign the response directly if it's an array of BGTables
      },
      error => {
        console.log(error);
        // Handle error if needed
      }
    );
  }


  onSubmit(): void {
    this.router.navigate(['/BillGeneratefinal',this.billGenerateTableId]);
  }
  }

