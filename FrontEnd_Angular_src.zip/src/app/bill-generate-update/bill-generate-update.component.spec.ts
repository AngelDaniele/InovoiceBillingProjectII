import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BillGenerateUpdateComponent } from './bill-generate-update.component';

describe('BillGenerateUpdateComponent', () => {
  let component: BillGenerateUpdateComponent;
  let fixture: ComponentFixture<BillGenerateUpdateComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [BillGenerateUpdateComponent]
    });
    fixture = TestBed.createComponent(BillGenerateUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
