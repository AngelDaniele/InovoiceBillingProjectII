import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { ProjectClients } from 'src/ProjectClient';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {



  constructor(private http: HttpClient) { }

  createProject(projectclient: ProjectClients): Observable<any> {
    return this.http.post("http://localhost:8080/project/saveproject", projectclient);
  }

  getProjectList(): Observable<any> {
    return this.http.get("http://localhost:8080/project/allproject");
  }

}
