import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectEmployeeListComponent } from './project-employee-list.component';

describe('ProjectEmployeeListComponent', () => {
  let component: ProjectEmployeeListComponent;
  let fixture: ComponentFixture<ProjectEmployeeListComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ProjectEmployeeListComponent]
    });
    fixture = TestBed.createComponent(ProjectEmployeeListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
