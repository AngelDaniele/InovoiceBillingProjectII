import { Component } from '@angular/core';
import { ProjectEmployeeService } from '../project-employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-project-employee-list',
  templateUrl: './project-employee-list.component.html',
  styleUrls: ['./project-employee-list.component.css']
})
export class ProjectEmployeeListComponent {

  projectEmployees:any;

  constructor(private projectEmployeeService: ProjectEmployeeService, private router: Router) { }
ngOnInit(): void {
  this.getProjectEmployeeList();
}

  getProjectEmployeeList(): void {
    this.projectEmployeeService.  getAllProjectEmployee().subscribe( projectEmployees => this. projectEmployees =  projectEmployees);
  }

}
