import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ProjectEmployeesUI } from 'src/ProjectEmployeeUI';


@Injectable({
  providedIn: 'root'
})
export class ProjectEmployeeService {


  projectemployeeUI:any;

  constructor(private http:HttpClient) { }

  saveProjectEmployee(  projectemployeeUI: ProjectEmployeesUI): Observable<any>{
    return this.http.post("http://localhost:8080/projectEmployee/save", projectemployeeUI);

  }

  getAllProjectEmployee():Observable<any>{

 return this.http.get("http://localhost:8080/projectEmployee/getProjectEmployee");
  }
 
}
