export class DesignationSummarys {

    
    designationSummaryId!:number;
    billGenerateTableId!:number;
    designation!: string;
    numberOfEmployees!: number;
    totalRate!: number;
    totalAmount!: number;
    billGenerateEndDate!: number;
   
    

}