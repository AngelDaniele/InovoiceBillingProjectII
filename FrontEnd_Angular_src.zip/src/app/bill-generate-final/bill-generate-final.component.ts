import { Component, OnInit } from '@angular/core';
import { DesignationSummarys } from './DesignationSummary';
import { ActivatedRoute, Router } from '@angular/router';
import { BillGenerateService } from '../bill-generate.service';
import { Invoices } from './Invoice';
import { BillGenerates } from '../bill-generate/BillGenerate';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';

@Component({
  selector: 'app-bill-generate-final',
  templateUrl: './bill-generate-final.component.html',
  styleUrls: ['./bill-generate-final.component.css']
})
export class BillGenerateFinalComponent implements OnInit{

  errorMessage = '';
  errorOccurred = false;
  billGenerateTableId=0;
  designationSummary:DesignationSummarys = new DesignationSummarys();
  designationSummarys:any;
  invoice:Invoices= new Invoices();
  invoices:Invoices[] = [];
  billGenerates:BillGenerates= new BillGenerates();

  constructor(private route: ActivatedRoute,private billGenerateService: BillGenerateService, private router: Router) { }
  ngOnInit(): void {
    this.route.params.subscribe(params => {
      const billGenerateTableId = +params['billGenerateTableId'];
      this.billGenerateTableId = billGenerateTableId;
      console.log('billGenerateTableId:', billGenerateTableId);
       this.calculateAndSaveDesignationSummary(billGenerateTableId,this.designationSummary);
       this.createInvoice(billGenerateTableId,this.invoice)
       this.getBillGenerateDataById(billGenerateTableId);
     
     
    });
  }
  printPage(){

    window.print();

    
    

}
  getBillGenerateDataById(billGenerateTableId: number): void {
    this.billGenerateService.getBillGenerateById(billGenerateTableId).subscribe(
      billGenerates => {
        this.billGenerates = billGenerates;
        // console.log(this.billGenerates);
      },
      error => {
        console.log(error);
        // Handle error if needed
      }
    );
  }

  calculateAndSaveDesignationSummary(billGenerateTableId: number, designationSummary:DesignationSummarys): void {
    this.billGenerateService.calculateAndSaveDesignationSummary( billGenerateTableId, designationSummary).subscribe(
      designationSummary => {
        console.log('Inserted designationSumamry data:',designationSummary)
         this. getDesignationSummariesByBillGenerateTableId(billGenerateTableId);
      },
      error => {
        console.log(error);
    
      }
    );
  }



  
  // ...
 
  
  createInvoice(billGenerateTableId: number,invoice:Invoices): void {
    this.billGenerateService.createInvoice( billGenerateTableId,invoice ).subscribe(
      invoice=> {
        console.log('Inserted invoice data:',invoice)
        //  this. getDesignationSummariesByBillGenerateTableId(billGenerateTableId);
        this. getInvoiceByBillGenerateTableId(billGenerateTableId)
        this.errorOccurred = false;
        this.errorMessage = '';
      },
      error => {
        console.log("the BillGenerate Amount Exceeds");
        this.errorOccurred = true;
        this.errorMessage = 'Total amount exceeds the project budget!';
    
      }
    );
  }

  getDesignationSummariesByBillGenerateTableId(billGenerateTableId: number): void {
    this.billGenerateService.getDesignationSummariesByBillGenerateTableId(billGenerateTableId).subscribe(
      response => {
        this. designationSummarys = response; // Assign the response directly if it's an array of BGTables
      },
      error => {
        console.log(error);
        // Handle error if needed
      }
    );
  }

  getInvoiceByBillGenerateTableId(billGenerateTableId: number): void {
    this.billGenerateService.getInvoiceByBillGenerateTableId(billGenerateTableId).subscribe(
      response => {
        this. invoices= [response]; // Assign the response directly if it's an array of BGTables
        console.log('get invoice:',this.invoices);
      },
      error => {
        console.log(error);
        console.log('error in get invoice');
      }
    );
  }

}
