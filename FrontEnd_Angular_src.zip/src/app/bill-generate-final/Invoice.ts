import { DecimalPipe } from "@angular/common";

export class Invoices {

    
    invoiceNumber!:number;
    billGenerateTableId!:number;
    cgst!:DecimalPipe;
    sgst!:DecimalPipe;
    subtotal!:number;
    totalAmount!:number;
   
   
    

}