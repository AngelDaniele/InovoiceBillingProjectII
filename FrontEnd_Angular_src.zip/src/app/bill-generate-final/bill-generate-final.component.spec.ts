import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BillGenerateFinalComponent } from './bill-generate-final.component';

describe('BillGenerateFinalComponent', () => {
  let component: BillGenerateFinalComponent;
  let fixture: ComponentFixture<BillGenerateFinalComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [BillGenerateFinalComponent]
    });
    fixture = TestBed.createComponent(BillGenerateFinalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
