export class Employees {
    
    employeeTableId!:number;
    employeeId!: string;
    employeeName!: string;
    designation!: string;
    technology!: string;
    address!: string;
    educationalQualification!: string;
   
   }
  