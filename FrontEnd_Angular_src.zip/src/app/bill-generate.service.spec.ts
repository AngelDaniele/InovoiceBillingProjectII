import { TestBed } from '@angular/core/testing';

import { BillGenerateService } from './bill-generate.service';

describe('BillGenerateService', () => {
  let service: BillGenerateService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BillGenerateService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
