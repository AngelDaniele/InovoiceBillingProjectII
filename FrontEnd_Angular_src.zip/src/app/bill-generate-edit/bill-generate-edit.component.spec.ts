import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BillGenerateEditComponent } from './bill-generate-edit.component';

describe('BillGenerateEditComponent', () => {
  let component: BillGenerateEditComponent;
  let fixture: ComponentFixture<BillGenerateEditComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [BillGenerateEditComponent]
    });
    fixture = TestBed.createComponent(BillGenerateEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
